ALTER TABLE siig_t_processo ALTER COLUMN id_processo TYPE NUMERIC(6,0);

ALTER TABLE siig_t_tracciamento ALTER COLUMN fk_processo TYPE NUMERIC(6,0);

