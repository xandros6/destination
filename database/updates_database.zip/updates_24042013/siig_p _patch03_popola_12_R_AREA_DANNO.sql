--pg 73 riga --> 1-E lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,1,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,2,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,3,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,4,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,5,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,6,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,1,7,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,1,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,2,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,3,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,4,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,5,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,6,32);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,2,7,32);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,1,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,2,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,3,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,4,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,5,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,6,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,3,7,51);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,1,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,2,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,3,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,4,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,5,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,6,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,4,7,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,10,15);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,1,5,16,0);



--pg 73 riga --> 1-E grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,1,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,2,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,3,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,4,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,5,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,6,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,1,7,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,1,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,2,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,3,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,4,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,5,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,6,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,2,7,90);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,3,7,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,1,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,2,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,3,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,4,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,5,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,6,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,4,7,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,10,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (1,5,0,5,16,0);
                      
--pg 73 riga --> 2-G lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,1,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,2,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,3,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,4,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,5,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,6,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,1,7,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,1,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,2,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,3,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,4,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,5,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,6,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,3,7,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,1,5,16,0);



--pg 73 riga --> 2-G grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,1,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,2,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,3,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,4,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,5,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,6,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,1,7,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,1,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,2,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,3,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,4,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,5,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,6,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,3,7,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (2,7,0,5,16,0);
                      

--pg 73 riga --> 3-D lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,1,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,2,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,3,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,4,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,5,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,6,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,1,7,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,1,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,2,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,3,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,4,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,5,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,6,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,2,7,70);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,1,5,16,0);



--pg 73 riga --> 3-D grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,1,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,2,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,3,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,4,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,5,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,6,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,1,7,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,1,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,2,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,3,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,4,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,5,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,6,132);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,2,7,132);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,4,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 3-F lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,1,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,2,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,3,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,4,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,5,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,6,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,1,7,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,1,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,2,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,3,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,4,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,5,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,6,95);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,2,7,95);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,3,7,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,1,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,2,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,3,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,4,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,5,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,6,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,4,7,140);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,10,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,1,5,16,0);



--pg 73 riga --> 3-F grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,1,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,2,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,3,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,4,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,5,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,6,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,1,7,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,1,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,2,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,3,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,4,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,5,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,6,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,2,7,230);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,1,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,2,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,3,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,4,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,5,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,6,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,3,7,420);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,1,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,2,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,3,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,4,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,5,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,6,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,4,7,500);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,10,180);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (3,6,0,5,16,0);
                      
                      
--pg 73 riga --> 4-D lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,1,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,2,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,3,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,4,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,5,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,6,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,1,7,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,1,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,2,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,3,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,4,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,5,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,6,65);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,2,7,65);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,1,5,16,0);



--pg 73 riga --> 4-D grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,1,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,2,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,3,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,4,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,5,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,6,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,1,7,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,1,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,2,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,3,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,4,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,5,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,6,148);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,2,7,148);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,4,0,5,16,0);
                      
                      
--pg 73 riga --> 4-F lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,1,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,2,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,3,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,4,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,5,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,6,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,1,7,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,1,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,2,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,3,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,4,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,5,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,6,93);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,2,7,93);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,1,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,2,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,3,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,4,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,5,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,6,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,3,7,100);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,1,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,2,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,3,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,4,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,5,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,6,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,4,7,131);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,10,55);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,1,5,16,0);



--pg 73 riga --> 4-F grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,1,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,2,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,3,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,4,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,5,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,6,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,1,7,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,1,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,2,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,3,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,4,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,5,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,6,210);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,2,7,210);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,1,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,2,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,3,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,4,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,5,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,6,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,3,7,339);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,1,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,2,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,3,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,4,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,5,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,6,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,4,7,467);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,10,112);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,6,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 4-M lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,1,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,2,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,3,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,4,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,5,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,6,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,1,7,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,3,7,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,1,5,16,0);



--pg 73 riga --> 4-M grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,1,7,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,1,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,2,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,3,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,4,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,5,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,6,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,3,7,230);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (4,11,0,5,16,0);
                      
                      
--pg 73 riga --> 5-B lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,1,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,2,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,3,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,4,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,5,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,6,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,1,7,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,1,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,2,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,3,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,4,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,5,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,6,96);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,2,7,96);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,1,5,16,0);



--pg 73 riga --> 5-B grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,1,7,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,1,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,2,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,3,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,4,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,5,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,6,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,2,7,150);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,2,0,5,16,0);
                      
                  
--pg 73 riga --> 5-L lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,1,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,2,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,3,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,4,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,5,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,6,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,1,7,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,1,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,2,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,3,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,4,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,5,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,6,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,3,7,567);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,1,5,16,0);



--pg 73 riga --> 5-L grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,1,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,2,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,3,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,4,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,5,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,6,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,1,7,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,1,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,2,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,3,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,4,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,5,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,6,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,3,7,780);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (5,10,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 6-G lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,1,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,2,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,3,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,4,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,5,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,6,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,1,7,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,1,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,2,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,3,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,4,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,5,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,6,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,3,7,81);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,1,5,16,0);



--pg 73 riga --> 6-G grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,1,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,2,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,3,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,4,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,5,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,6,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,1,7,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,1,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,2,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,3,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,4,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,5,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,6,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,3,7,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (6,7,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 7-H lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,13,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,14,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,15,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,1,5,16,0);



--pg 73 riga --> 7-H grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,13,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,14,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,15,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (7,8,0,5,16,0);
                      
                      
--pg 73 riga --> 8-H lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,13,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,14,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,15,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,1,5,16,0);



--pg 73 riga --> 8-H grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,13,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,14,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,15,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,8,0,5,16,0);
                      
                      
--pg 73 riga --> 10-H lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,13,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,14,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,15,8);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,1,5,16,0);



--pg 73 riga --> 10-H grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,1,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,13,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,14,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,15,25);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (10,8,0,5,16,0);
                      
                   
--pg 73 riga --> 8-C lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,1,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,2,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,3,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,4,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,5,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,6,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,1,7,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,1,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,2,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,3,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,4,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,5,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,6,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,2,7,45);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,1,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,2,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,3,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,4,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,5,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,6,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,3,7,52);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,1,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,2,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,3,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,4,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,5,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,6,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,4,7,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,10,35);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,1,5,16,0);



--pg 73 riga --> 8-C grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,1,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,2,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,3,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,4,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,5,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,6,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,1,7,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,1,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,2,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,3,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,4,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,5,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,6,110);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,2,7,110);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,1,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,2,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,3,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,4,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,5,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,6,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,3,7,130);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,1,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,2,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,3,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,4,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,5,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,6,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,4,7,145);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,10,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,3,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 8-D lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,1,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,2,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,3,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,4,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,5,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,6,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,1,7,45);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,1,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,2,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,3,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,4,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,5,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,6,90);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,2,7,90);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,1,5,16,0);



--pg 73 riga --> 8-D grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,1,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,2,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,3,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,4,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,5,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,6,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,1,7,127);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,1,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,2,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,3,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,4,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,5,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,6,250);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,2,7,250);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (8,4,0,5,16,0);
                      
                      
                      
--pg 73 riga --> 9-B lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,1,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,2,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,3,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,4,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,5,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,6,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,1,7,40);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,1,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,2,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,3,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,4,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,5,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,6,88);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,2,7,88);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,1,5,16,0);



--pg 73 riga --> 9-B grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,1,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,2,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,3,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,4,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,5,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,6,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,1,7,70);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,1,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,2,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,3,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,4,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,5,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,6,150);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,2,7,150);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,3,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,2,0,5,16,0);
                      
                      
--pg 73 riga --> 9-I lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,1,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,2,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,3,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,4,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,5,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,6,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,1,7,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,1,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,2,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,3,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,4,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,5,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,6,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,3,7,60);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,1,5,16,0);



--pg 73 riga --> 9-I grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,1,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,2,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,3,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,4,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,5,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,6,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,1,7,80);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,2,7,0);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,1,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,2,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,3,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,4,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,5,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,6,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,3,7,160);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,1,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,2,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,3,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,4,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,5,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,6,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,4,7,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,10,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,9,0,5,16,0);
                      
                      
--pg 73 riga --> 9-A lieve
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,1,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,2,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,3,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,4,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,5,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,6,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,1,7,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,1,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,2,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,3,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,4,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,5,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,6,42);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,2,7,42);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,1,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,2,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,3,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,4,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,5,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,6,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,3,7,48);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,1,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,2,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,3,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,4,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,5,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,6,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,4,7,58);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,10,30);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,1,5,16,0);



--pg 73 riga --> 9-A grave
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,1,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,2,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,3,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,4,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,5,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,6,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,1,7,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,1,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,2,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,3,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,4,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,5,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,6,109);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,2,7,109);                      
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,1,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,2,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,3,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,4,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,5,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,6,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,3,7,125);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,1,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,2,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,3,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,4,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,5,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,6,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,4,7,138);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,10,75);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,11,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,12,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,13,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,14,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,15,0);
INSERT INTO siig_r_area_danno(id_sostanza,id_scenario,flg_lieve,id_gravita,id_bersaglio,fk_distanza) 
                      VALUES (9,1,0,5,16,0);