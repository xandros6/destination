delete from siig_t_elab_standard_1;
delete from siig_t_elab_standard_2;
delete from siig_t_elab_standard_3;

delete from siig_t_vulnerabilita_1;
delete from siig_t_vulnerabilita_2;
delete from siig_t_vulnerabilita_3;

delete from siig_r_area_danno;

delete from siig_d_distanza;

delete from siig_r_scenario_gravita;

delete from siig_d_gravita;
