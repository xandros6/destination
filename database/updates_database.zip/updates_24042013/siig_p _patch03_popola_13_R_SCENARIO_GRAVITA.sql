--ps 99 Scenario A bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,1,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,2,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,3,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,4,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,5,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,6,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,1,7,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,1,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,2,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,3,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,4,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,5,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,6,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,3,7,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,1,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,2,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,3,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,4,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,5,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,6,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,4,7,0.0035);
    
--ps 99 Scenario C bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,1,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,2,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,3,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,4,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,5,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,6,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,1,7,0.2225);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,1,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,2,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,3,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,4,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,5,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,6,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,3,7,0.0950);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,1,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,2,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,3,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,4,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,5,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,6,0.0035);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,4,7,0.0035);
    
    
--ps 99 Scenario B bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,1,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,2,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,3,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,4,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,5,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,6,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,1,7,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,1,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,2,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,3,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,4,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,5,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,6,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,3,7,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,4,7,0);
    
 
--ps 99 Scenario D bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,1,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,2,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,3,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,4,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,5,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,6,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,1,7,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,1,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,2,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,3,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,4,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,5,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,6,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,3,7,0.1575);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,4,7,0);
    
    
--ps 99 Scenario E bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,1,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,2,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,3,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,4,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,5,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,6,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,1,7,0.0278);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,1,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,2,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,3,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,4,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,5,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,6,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,3,7,0.0119);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,1,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,2,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,3,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,4,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,5,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,6,0.0004);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,4,7,0.0004);
    
    
--ps 99 Scenario F bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,1,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,2,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,3,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,4,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,5,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,6,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,1,7,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,1,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,2,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,3,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,4,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,5,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,6,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,3,7,0.6300);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,1,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,2,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,3,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,4,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,5,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,6,0.0150);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,4,7,0.0150);
    

--ps 99 Scenario I bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,1,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,2,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,3,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,4,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,5,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,6,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,1,7,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,1,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,2,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,3,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,4,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,5,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,6,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,3,7,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,1,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,2,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,3,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,4,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,5,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,6,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,4,7,0.0001);
    
--ps 99 Scenario L bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,1,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,2,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,3,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,4,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,5,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,6,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,1,7,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,1,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,2,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,3,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,4,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,5,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,6,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,3,7,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,1,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,2,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,3,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,4,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,5,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,6,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,4,7,0.0001);
    
    
--ps 99 Scenario M bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,1,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,2,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,3,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,4,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,5,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,6,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,1,7,0.0281);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,1,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,2,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,3,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,4,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,5,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,6,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,3,7,0.0038);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,1,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,2,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,3,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,4,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,5,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,6,0.0001);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,4,7,0.0001);
    
    
--ps 99 Scenario G bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,1,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,3,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,4,7,0);
    
    
--ps 99 Scenario H bersagli umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,1,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,2,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,3,7,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,1,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,2,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,3,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,4,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,5,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,6,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,4,7,0);
    
    
--pg 100 Scenario A bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,10,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,11,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,12,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,13,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (1,5,16,0);
    
    
--pg 100 Scenario C bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,10,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,11,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,12,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,13,0.2500);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (3,5,16,0);
    
    
--pg 100 Scenario M bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,11,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,12,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,13,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (11,5,16,0);
    
--pg 100 Scenario L bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,11,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,12,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,13,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (10,5,16,0);
    
    
--pg 100 Scenario I bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,11,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,12,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,13,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (9,5,16,0);
    
    
--pg 100 Scenario H bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,11,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,12,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,13,0.1250);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,14,0.1250);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,15,0.1250);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (8,5,16,0);
    
    
--pg 100 Scenario G bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,11,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,12,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,13,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (7,5,16,0);
    
    
--pg 100 Scenario E bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,10,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,11,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,12,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,13,0.0313);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (5,5,16,0);
    
--pg 100 Scenario B bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,11,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,12,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,13,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (2,5,16,0);
    
    
--pg 100 Scenario D bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,10,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,11,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,12,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,13,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (4,5,16,0);
    
    
--pg 100 Scenario F bersagli non umani

INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,10,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,11,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,12,1);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,13,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,14,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,15,0);
INSERT INTO siig_r_scenario_gravita(id_scenario,id_gravita,id_bersaglio,suscettibilita)
    VALUES (6,5,16,0);